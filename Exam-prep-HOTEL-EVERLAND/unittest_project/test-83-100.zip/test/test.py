from project.student_report_card import StudentReportCard
import unittest


class TestStudentReportCard(unittest.TestCase):
    def test_1_init(self):
        rs_report_card = StudentReportCard("RS", 11)
        self.assertEqual("RS", rs_report_card.student_name)
        self.assertEqual(11, rs_report_card.school_year)
        self.assertEqual({}, rs_report_card.grades_by_subject)

    def test_2_name_empty_str(self):
        rs_report_card = StudentReportCard("RS", 11)
        with self.assertRaises(ValueError) as ex:
            rs_report_card.student_name = ''
        self.assertEqual("Student Name cannot be an empty string!", str(ex.exception))

    def test_2_name_valid__str(self):
        rs_report_card = StudentReportCard("RS", 11)
        self.assertEqual("RS", rs_report_card.student_name)

    def test_3_year_between_1_12(self):
        rs_report_card = StudentReportCard("RS", 11)
        with self.assertRaises(ValueError) as ex:
            rs_report_card.school_year = 22
        self.assertEqual("School Year must be between 1 and 12!", str(ex.exception))

    def test_3_valid_year(self):
        rs_report_card = StudentReportCard("RS", 11)
        self.assertEqual(11, rs_report_card.school_year)

    def test_4_add_grade(self):
        rs_report_card = StudentReportCard("RS", 11)
        rs_report_card.add_grade("Math", 5.20)
        self.assertEqual({'Math': [5.20]}, rs_report_card.grades_by_subject)
        rs_report_card.add_grade("Math", 5.60)
        self.assertEqual({'Math': [5.2, 5.60]}, rs_report_card.grades_by_subject)
        rs_report_card.add_grade("Geog", 4.50)
        self.assertEqual({'Math': [5.2, 5.60], 'Geog': [4.5]}, rs_report_card.grades_by_subject)

    def test_4_add_grade_if_subject_in_subjects(self):
        rs_report_card = StudentReportCard("RS", 11)
        rs_report_card.add_grade("Math", 5.20)
        rs_report_card.add_grade("Math", 5.60)
        rs_report_card.add_grade("Geog", 4.50)
        self.assertEqual({'Math': [5.2, 5.60], 'Geog': [4.50]}, rs_report_card.grades_by_subject)

    def test_5_av_grade_by_subject(self):
        rs_report_card = StudentReportCard("RS", 11)
        rs_report_card.add_grade("Math", 5.20)
        rs_report_card.add_grade("Math", 5.60)
        rs_report_card.add_grade("Geog", 4.50)
        test_res = "Math: 5.40\nGeog: 4.50"
        self.assertEqual(test_res, rs_report_card.average_grade_by_subject())

    def test_5_av_grade_calc_formula(self):
        rs_report_card = StudentReportCard("RS", 11)
        rs_report_card.add_grade("Math", 5.20)
        rs_report_card.add_grade("Math", 5.60)
        sum_grades = 0
        len_grades = 0
        for k, v in rs_report_card.grades_by_subject.items():
            sum_grades = sum(v)
            len_grades = len(v)
        av_grade = sum_grades / len_grades
        self.assertEqual(5.40, av_grade)

    def test_6_av_grade_for_all_subjects(self):
        rs_report_card = StudentReportCard("RS", 11)
        rs_report_card.add_grade("Math", 5.20)
        rs_report_card.add_grade("Math", 5.60)
        rs_report_card.add_grade("Geog", 4.50)
        test_res = "Average Grade: 5.10"
        self.assertEqual(test_res, rs_report_card.average_grade_for_all_subjects())

    def test_6_av_grade_for_all(self):
        rs_report_card = StudentReportCard("RS", 11)
        rs_report_card.add_grade("Math", 5.20)
        rs_report_card.add_grade("Math", 5.60)
        rs_report_card.add_grade("Geog", 4.50)
        sum_all_grades = 0
        for k, v in rs_report_card.grades_by_subject.items():
            sum_all_grades += sum(v)
        self.assertEqual(15.30, sum_all_grades)

    def test_7_repr(self):
        rs_report_card = StudentReportCard("RS", 11)
        rs_report_card.add_grade("Math", 5.20)
        rs_report_card.add_grade("Math", 5.60)
        rs_report_card.add_grade("Geog", 4.50)
        result = "Name: RS\nYear: 11\n----------\nMath: 5.40\nGeog: 4.50\n----------\nAverage Grade: 5.10"
        self.assertEqual(result, rs_report_card.__repr__())


if __name__ == '__main__':
    unittest.main()
