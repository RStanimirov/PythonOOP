from project.library import Library
import unittest


class Test(unittest.TestCase):
    # def setUp(self) -> None:
    #     pernik_library = Library("Pernik Library")

    def test_init(self):
        pernik_library = Library("Pernik Library")
        self.assertEqual("Pernik Library", pernik_library.name)
        self.assertEqual({}, pernik_library.books_by_authors)
        self.assertEqual({}, pernik_library.readers)

    def test_name_empty_string_raise_value_error(self):
        with self.assertRaises(ValueError) as ex:
            pernik_library = Library("")
        self.assertEqual("Name cannot be empty string!", str(ex.exception))

    def test_add_book(self):
        pernik_library = Library("Pernik Library")
        pernik_library.add_book("Walter Scott", "Ivanhoe")
        pernik_library.add_book("Walter Scott", "Ivanhoe")
        pernik_library.add_book("Walter Scott", "Waverly")
        pernik_library.add_book("Albert Camus", "The Stranger")
        self.assertEqual({'Walter Scott': ['Ivanhoe', 'Waverly'], 'Albert Camus': ['The Stranger']},
                         pernik_library.books_by_authors)
        # self.assertEqual(2, len(pernik_library.books_by_authors))
        # self.assertTrue("Walter Scott" in pernik_library.books_by_authors)
        # self.assertEqual(["Ivanhoe", "Waverly"], pernik_library.books_by_authors["Walter Scott"])

    def test_add_reader_return_text(self):
        pernik_library = Library("Pernik Library")
        pernik_library.add_reader("RS")
        pernik_library.add_reader("Eva")
        self.assertEqual("RS is already registered in the Pernik Library library.",
                         pernik_library.add_reader("RS"))

    def test_add_readers_to_library(self):
        pernik_library = Library("Pernik Library")
        pernik_library.add_reader("RS")
        pernik_library.add_reader("Eva")
        self.assertEqual({'RS': [], 'Eva': []}, pernik_library.readers)
        # self.assertEqual(2, len(pernik_library.readers))
        # self.assertTrue("RS" in pernik_library.readers)
        # self.assertEqual([], pernik_library.readers["RS"])

    def test_rent_book_successful(self):
        pernik_library = Library("Pernik Library")
        pernik_library.add_book("Walter Scott", "Ivanhoe")
        pernik_library.add_book("Walter Scott", "Waverly")
        pernik_library.add_book("Albert Camus", "The Stranger")
        pernik_library.add_reader("RS")
        pernik_library.add_reader("Eva")
        self.assertEqual({'RS': [], 'Eva': []}, pernik_library.readers)
        pernik_library.rent_book("RS", "Walter Scott", "Ivanhoe")
        self.assertEqual({'RS': [{'Walter Scott': 'Ivanhoe'}], 'Eva': []}, pernik_library.readers)
        # book_title_index = pernik_library.books_by_authors["Walter Scott"].index("Ivanhoe")
        # self.assertEqual([{"Walter Scott": "Ivanhoe"}], pernik_library.readers["RS"])
        # self.assertEqual(1, len(pernik_library.books_by_authors["Walter Scott"]))
        self.assertEqual({'Walter Scott': ['Waverly'], 'Albert Camus': ['The Stranger']},
                         pernik_library.books_by_authors)
        # self.assertTrue("Ivanhoe" not in pernik_library.books_by_authors["Walter Scott"])
        # self.assertTrue("Waverly" in pernik_library.books_by_authors["Walter Scott"])

    def test_rent_book_if_reader_not_in_readers(self):
        pernik_library = Library("Pernik Library")
        pernik_library.add_book("Walter Scott", "Ivanhoe")
        pernik_library.add_book("Walter Scott", "Waverly")
        pernik_library.add_book("Albert Camus", "The Stranger")
        pernik_library.add_reader("RS")
        pernik_library.add_reader("Eva")
        self.assertEqual("John is not registered in the Pernik Library Library.",
                         pernik_library.rent_book("John", "Walter Scott", "Waverly"))

    def test_rent_book_if_book_author_not_in_books(self):
        pernik_library = Library("Pernik Library")
        pernik_library.add_book("Walter Scott", "Ivanhoe")
        pernik_library.add_book("Walter Scott", "Waverly")
        pernik_library.add_book("Albert Camus", "The Stranger")
        pernik_library.add_reader("RS")
        pernik_library.add_reader("Eva")
        self.assertEqual("Pernik Library Library does not have any Astrid Lindgren's books.",
                         pernik_library.rent_book("Eva", "Astrid Lindgren", "Pippi Longsocks"))

    def test_rent_book_if_book_title_not_in_books(self):
        pernik_library = Library("Pernik Library")
        pernik_library.add_book("Walter Scott", "Ivanhoe")
        pernik_library.add_book("Walter Scott", "Waverly")
        pernik_library.add_book("Albert Camus", "The Stranger")
        pernik_library.add_reader("RS")
        pernik_library.add_reader("Eva")
        self.assertEqual("""Pernik Library Library does not have Walter Scott's "Rob Roy".""",
                         pernik_library.rent_book("RS", "Walter Scott", "Rob Roy"))


if __name__ == '__main__':
    unittest.main()

# class Test(unittest.TestCase):
#     def setUp(self) -> None:
#         self.library = Library('Library')
#
#     def test_library_raises_error_when_empty_string_is_passed(self):
#         with self.assertRaises(ValueError) as context:
#             library = Library('')
#
#         self.assertEqual('Name cannot be empty string!', str(context.exception))
#
#     def test_library_initialization(self):
#         self.assertEqual('Library', self.library.name)
#         self.assertEqual({}, self.library.books_by_authors)
#         self.assertEqual({}, self.library.readers)
#
#     def test_add_book_should_add_author_and_title(self):
#         author = 'Author'
#         first_title = 'Title1'
#         second_title = 'Title2'
#         self.library.add_book(author, first_title)
#         self.library.add_book(author, first_title)
#         self.library.add_book(author, second_title)
#
#         self.assertEqual(1, len(self.library.books_by_authors))
#         self.assertTrue(author in self.library.books_by_authors)
#         self.assertEqual([first_title, second_title], self.library.books_by_authors[author])
#
#     def test_add_reader_should_add_the_reader(self):
#         reader_name = 'Reader'
#         self.library.add_reader(reader_name)
#
#         self.assertEqual(1, len(self.library.readers))
#         self.assertTrue(reader_name in self.library.readers)
#         self.assertEqual([], self.library.readers[reader_name])
#
#     def test_add_reader_should_return_error_message_when_reader_is_already_registered(self):
#         reader_name = 'Reader'
#         self.library.add_reader(reader_name)
#         result = self.library.add_reader(reader_name)
#
#         self.assertEqual(f"{reader_name} is already registered in the {self.library.name} library.", result)
#
#     def test_rent_book_should_return_error_message_when_reader_is_not_registered(self):
#         reader_name = 'reader'
#         result = self.library.rent_book(reader_name, 'author', 'title')
#         self.assertEqual(f"{reader_name} is not registered in the {self.library.name} Library.", result)
#
#     def test_rent_book_should_return_error_message_when_author_is_not_registered(self):
#         reader_name = 'reader'
#         author_name = 'author'
#         self.library.add_reader(reader_name)
#
#         result = self.library.rent_book(reader_name, author_name, 'title')
#         self.assertEqual(f"{self.library.name} Library does not have any {author_name}'s books.", result)
#
#     def test_rent_book_should_return_error_message_when_title_is_not_registered(self):
#         reader_name = 'reader'
#         author_name = 'author'
#         invalid_title = 'title'
#         self.library.add_reader(reader_name)
#         self.library.add_book(author_name, 'random title')
#
#         result = self.library.rent_book(reader_name, author_name, invalid_title)
#         self.assertEqual(f"""{self.library.name} Library does not have {author_name}'s "{invalid_title}".""", result)
#
#     def test_rent_book_should_properly_rent_book(self):
#         reader_name = 'reader'
#         author_name = 'author'
#         first_title = 'title1'
#         second_title = 'title2'
#         self.library.add_reader(reader_name)
#         self.library.add_book(author_name, first_title)
#         self.library.add_book(author_name, second_title)
#
#         self.library.rent_book(reader_name, author_name, first_title)
#
#         self.assertEqual([{author_name: first_title}], self.library.readers[reader_name])
#         self.assertEqual(1, len(self.library.books_by_authors[author_name]))
#         self.assertTrue(first_title not in self.library.books_by_authors[author_name])
#         self.assertTrue(second_title in self.library.books_by_authors[author_name])
#
#
# if __name__ == '__main__':
#     unittest.main()
